function widgetData() {
    let Temperature = ["0°C alatt", "0°C - 15°C", "15 °C - 20 °C", "20 °C - 25 °C", "25 °C-tól"];
    let offers = ["forró csoki", "meleg tea", "finom süti", "fagyi", "jéghideg limonádé"];
    let maxTemp = ["-12", "3", "9", "14", "18", "22", "27"]; /*Index 0 = Monday Index 1 = Tuesday ... to Index 6 = Sunday.*/
    let minTemp = ["-12", "3", "9", "14", "18", "22", "27"];
    let avgTemp = ["-12", "3", "9", "14", "18", "22", "27"];
    let maxTempS = document.querySelector(".maxTemp");
    let minTempS = document.querySelector(".minTemp");
    let avgTempS = document.querySelector(".avgTemp");

    weatherWidget(Temperature, offers, maxTempS, minTempS, avgTempS, avgTemp, minTemp, maxTemp)
}
function weatherWidget(Temperature, offers, maxTempS, minTempS, avgTempS, avgTemp, minTemp, maxTemp) {
    let e = document.querySelector("#weatherWidget-menu");
    result = e.options[e.selectedIndex].text;
    let avgTempData
    if (result == "Hétfő") {
        maxTempS.innerHTML = maxTemp[0];
        minTempS.innerHTML = minTemp[0];
        avgTempS.innerHTML = avgTemp[0];
        avgTempData = avgTemp[0];
    } else if (result == "Kedd") {
        maxTempS.innerHTML = maxTemp[1];
        minTempS.innerHTML = minTemp[1];
        avgTempS.innerHTML = avgTemp[1];
        avgTempData = avgTemp[1];
    } else if (result == "Szerda") {
        maxTempS.innerHTML = maxTemp[2];
        minTempS.innerHTML = minTemp[2];
        avgTempS.innerHTML = avgTemp[2];
        avgTempData = avgTemp[2];
    } else if (result == "Csütörtök") {
        maxTempS.innerHTML = maxTemp[3];
        minTempS.innerHTML = minTemp[3];
        avgTempS.innerHTML = avgTemp[3];
        avgTempData = avgTemp[3];
    } else if (result == "Péntek") {
        maxTempS.innerHTML = maxTemp[4];
        minTempS.innerHTML = minTemp[4];
        avgTempS.innerHTML = avgTemp[4];
        avgTempData = avgTemp[4];
    } else if (result == "Szombat") {
        maxTempS.innerHTML = maxTemp[5];
        minTempS.innerHTML = minTemp[5];
        avgTempS.innerHTML = avgTemp[5];
        avgTempData = avgTemp[5];
    } else {
        maxTempS.innerHTML = maxTemp[6];
        minTempS.innerHTML = minTemp[6];
        avgTempS.innerHTML = avgTemp[6];
        avgTempData = avgTemp[6];
    }
    
    offersCalc(offers, avgTempData)
}

function offersCalc(offers, avgTempData) {
    let giftText = document.querySelector("#giftText");
    let avgTempDataNumber = parseFloat(avgTempData);
    if (avgTempDataNumber < 0) {
        giftText.innerHTML = offers[0]
    } else if (avgTempDataNumber >= 0 && avgTempDataNumber < 15) {
        giftText.innerHTML = offers[1]
    } else if (avgTempDataNumber >= 15 && avgTempDataNumber < 20) {
        giftText.innerHTML = offers[2]
    } else if (avgTempDataNumber >= 20 && avgTempDataNumber < 25) {
        giftText.innerHTML = offers[3]
    } else {
        giftText.innerHTML = offers[4]
    }
}