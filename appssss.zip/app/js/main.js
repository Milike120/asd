function calcAmount() {
    let price = 1000;
    let amountInput = document.querySelector("input[name=number]");
    let priceField = document.querySelector(".message strong");
    let amount = parseInt(amountInput.value);
    let amountNumber = parseInt(amountInput.value);
    let totalAmount = amount * price;

    isValid(totalAmount, amountNumber, priceField) 
}

function isValid(totalAmount, amountNumber, priceField) {
    if (isNaN(amountNumber)) {
        alert("Kérjük töltse ki az összes mezőt");
        return;
    } if (amountNumber > 10) {
        alert("Maximum 10 terméket vásárolhat");
        return;
    } else if (amountNumber < 1) {
        alert("Minimum 1 terméket kell vásárolnia");
        return;
    }

    isSuccess(totalAmount, priceField);
}

function isSuccess(totalAmount, priceField) {
    if (totalAmount >= 5000) {
        alert("Sikeres rendelés!");
        priceField.innerHTML = totalAmount;
    } else {
        alert("Sikeres rendelés!");
        priceField.innerHTML = totalAmount + 500;
    }
}