let fetchInit = {
    method: "GET",
    headers: new Headers(),
    mode: "cors",
    cache: "default"
  };
  const postPromise = fetch("http://localhost:3000/users");
postPromise
  .then(data => data.json())
  .then(data => {
    let tableBody = document.querySelector("tbody");
createTD = (html, parent) => {
    let td = document.createElement("td");
    td.innerHTML = html;
    parent.appendChild(td);
}
for (let k in data) {
    let tr = document.createElement("tr");
    for (let value of Object.values(data[k])) {
        createTD(value, tr)
    }
    tableBody.appendChild(tr);
}
  })
  .catch(err => {
    console.log(err);
  });
  
  
